package com.uunemo.beans;

public class Company {

}
